const connection = require("../config/connection");

exports.getUsers = async (req, res) => {
  let data = [];
  try {
    let sql = "select * from t_students";

    const exec = connection.query(sql, function (err, rows, fields) {
      if (err) throw err;
      res.json({
        status: true,
        data: rows,
        msg: "Hello",
      });
    });
  } catch (error) {
    return res.json({
      status: false,
      msg: error.message,
    });
  }
};

exports.insertUser = async (req, res) => {
    try {
      const body = req.body;
      let name = body.name;
      let age = body.age;
      let gender = body.gender;
  
      let sql = `insert into t_students(name,age,gender) values (?, ?, ?) `;
      let values = [name, age, gender];
    } catch (error) {
      return res.json({
        status: false,
        msg: error.message,
      });
    }
  };

  exports.updateUser = async (req, res) => {
    try {
      const id = req.params.id;
      const body = req.body;
      let name = body.name;
      let age = body.age;
      let gender = body.gender;
  
      let sql = `update t_students set name=?, age=?, gender=? where id=? `;
      let values = [name, age, gender, id];
  
      connection.query(sql, values, function (err, rows, fields) {
        if (err) throw err;
  
        if (rows.affectedRows > 0) {
          msg = "Successfully Update";
        } else {
          msg = "No entry was updated";
        }
  
        res.json({
          status: true,
          msg: msg,
        });
      });
    } catch (error) {
      return res.json({
        status: false,
        msg: error.message,
      });
    }
  };

  exports.deleteUser = async (req, res) => {
    try {
      const id = req.params.id;
  
      let sql = ` delete from t_students where id = ${id} `;
  
      connection.query(sql, function (err, rows, fields) {
        if (err) throw err;
        let msg = "";
        if (rows.affectedRows > 0) {
          msg = "Successfully Delete";
        } else {
          msg = "No entry was deleted";
        }
  
        res.json({
          status: true,
          msg: msg,
        });
      });
    } catch (error) {
      res.json({
        status: true,
        msg: error.message,
      });
    }
  };