const express = require('express')

const siswaController = require('../controller/siswaController')

const router = express.Router()

router.get('/', siswaController.getUsers)
router.get('/:id', siswaController.getUsersById)
router.post('/', siswaController.CreateUser)
router.put('/:id', siswaController.updateUser)
router.delete('/:id', siswaController.deleteUser)

module.exports = router