const express = require('express')
const cors = require('cors')
const siswaRoute = require('./route/siswaRouter')

const app = express()
const port = 3000

// middleware 
app.use(cors());
app.use(express.json());
app.use('/siswa', siswaRoute)

app.listen(port, ()=>{
  console.log(`Listening on port ${port}`);
})