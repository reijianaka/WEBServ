const coba = require('./kuis');
//console.log(kuis.namaku('frans'));

console.log(
    coba.namaku('frans'),
    coba.sw,
    coba.mahasiswa(),
    new coba.vk()
    
);