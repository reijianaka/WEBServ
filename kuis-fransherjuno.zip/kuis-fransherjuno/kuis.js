function namaku(nama) {
    return `Hai, nama saya ${nama}`;
}

const sw = "siswa";


const mahasiswa = {
    name: "jun",  
    npm: 053,
    
    prodi(){
        return `saya mhs WS, nama ${this.name} dan npm ${this.npm}.`;
    },
};

class vk {
    vaksin(){
        console.log('obj vaksin created');
    }
};

module.exports.namaku = namaku;